$(function() {
	var isRow = false;
	var itemTpl = $('script[data-template="griditem"]').text().split(
			/\$\{(.+?)\}/g);

	function render(props) {
		return function(tok, i) {
			return (i % 2) ? props[tok] : tok;
		};
	}

	var loadUserData = function(firstName, lastName) {
		var apiKey = "TPocU1p2nawMIlUtuwwlayQ3GlS526fZqeO7";
		var url = "https://gorest.co.in/public-api/users"
		if (firstName && lastName) {
			url = "https://gorest.co.in/public-api/users?first_name=" + firstName + "&last_name=" + lastName;
		} else if(firstName) {
			url = "https://gorest.co.in/public-api/users?first_name=" + firstName;
		} else if(lastName) {
			url = "https://gorest.co.in/public-api/users?last_name=" + lastName;
		}
		
		$.ajax({
			method : "GET",
			url : url,
			headers : {
				"Authorization" : "Bearer " + apiKey
			}
		}).done(function(response) {

			var users = response.result;

			var userGrid = $('#user-grid');
			userGrid.empty();
			userGrid.append(users.map(function(user) {
				return itemTpl.map(render(user)).join('');
			}));
			if(isRow=== true) {
				
				$( ".user-item" ).removeClass("col-md-4");
				$( ".user-item" ).addClass("col-md-12");
			}
			else {
				
				$( ".user-item" ).removeClass("col-md-12");
				$( ".user-item" ).addClass("col-md-4");
			}
		});
	}
	
	$("#search").click(function() {
		var firstName = $("#first-name").val();
		var lastName = $("#last-name").val();
		loadUserData(firstName, lastName);
		
	});
	
	$("#ChangeView").click(function() {
		
		
		if(isRow=== false) {
			isRow = true;
			$( ".user-item" ).removeClass("col-md-4");
			$( ".user-item" ).addClass("col-md-12");
		}
		else {
			isRow = false;
			$( ".user-item" ).removeClass("col-md-12");
			$( ".user-item" ).addClass("col-md-4");
		}
		
		
		
	});
	

	loadUserData();
})